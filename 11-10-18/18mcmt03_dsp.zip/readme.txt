Dear User,
	I have constructed the binary search tree first with some number of elements and then I have included the code for in-order, pre-order, post-order traversals in the same code itself. 
	So, there are no separate files for each of the programs.

